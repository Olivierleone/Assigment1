<?php
namespace app\models;

class Message{

	public $email;
	public $message;

public function __construct($object = null){
			if($object == null)
				return; 
			//TODO: avoid this running when there is no parameter
			$this->email = $object->email;
			$this->message = $object->message;
		
		}
		public function insert(){

			 $ip_address = $_SERVER['REMOTE_ADDR'];


			  $data = array(
        'email' => $this->email,
        'message' => $this->message,
        'ip_address' => $ip_address
    );

			   $data_json = json_encode($data);

			$filename = 'resources/Messages.txt';

			$file_handle = fopen($filename, 'a');

			flock($file_handle, LOCK_EX);

			

			fwrite($file_handle, $data_json . "\n");

			flock($file_handle, LOCK_UN);

			fclose($file_handle);
		}

public static function read()
{
    // Define the path to the log file
    $logFilePath = __DIR__ . "/../../resources/messages.txt";

    // Read messages from the log file
    $lines = file($logFilePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    // Initialize an empty array to store parsed messages
    $messages = [];

    // Iterate over each line and parse JSON data into objects
    foreach ($lines as $line) {
        // Decode JSON data into an associative array
        $data = json_decode($line, true);

        // Create a new Message object and add it to the messages array
        $message = new Message();
        $message->email = $data['email'];
        $message->message = $data['message'];
        $messages[] = $message;
    }

    // Return the array of parsed messages
    return $messages;
}


		public static function getAll()
{
    $filename = 'resources/Messages.txt';

    // Read lines from the file
    $lines = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    // Initialize an array to store parsed messages
    $messages = [];

    // Iterate over each line and decode JSON data
    foreach ($lines as $line) {
        // Decode JSON data into an associative array
        $data = json_decode($line, true);

        // Create a new Message object and add it to the messages array
        $message = new Message();
        $message->email = $data['email'];
        $message->message = $data['message'];
        $messages[] = $message;
    }

    // Return the array of parsed messages
    return $messages;
}

}