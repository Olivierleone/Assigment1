<?php
namespace app\controllers;

use stdClass;

class Message extends \app\core\Controller{

    function contact(){
        $this->view('Message/contact');
    }


   public function read()
{
    // Retrieve messages from the Message model
    $messages = \app\models\Message::read();

    // Pass the messages to the view
    $this->view('Message/read', ['messages' => $messages]);
}



}