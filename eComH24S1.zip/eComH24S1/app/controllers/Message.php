<?php
namespace app\controllers;

use stdClass;

class Message extends \app\core\Controller{

    function contact(){
        $this->view('Message/contact');
    }


    function read(){


        $message = new \app\models\Message();

        $message->email = $_POST['email'];
        $message->message = $_POST['message'];

        $message->insert();
        $this->view('Message/read',$message);
    }




}